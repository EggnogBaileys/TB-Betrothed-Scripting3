using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class EndBattle : MonoBehaviour
{
    public CombatStateManager combatStateManager;
    GameObject spear;

    public AudioSource battleMusic;

    public TextMeshPro endCombatText;

    public string nextScene;

    void Start()
    {
        
    }

    public void EndCombat(string status)
    {
        Destroy(combatStateManager);

        Destroy(GameObject.Find("HealthBar"));

        this.gameObject.GetComponent<AudioSource>().Play(0);

        battleMusic.Stop();

        if (status == "Loss")
        {
            endCombatText.text = "YOU PERISHED";
        }
        else if (status == "Victory")
        {
            endCombatText.text = "FOE VANQUISHED";
        }

        StartCoroutine(NextScene(status));
    }


    IEnumerator NextScene(string status)
    {
        yield return new WaitForSeconds(2.25f);

        if (status == "Victory" & nextScene != "") SceneManager.LoadScene(nextScene);

        else
        {
            Manager.instance.totalDeaths += 1;
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        } 
            
    }

}
