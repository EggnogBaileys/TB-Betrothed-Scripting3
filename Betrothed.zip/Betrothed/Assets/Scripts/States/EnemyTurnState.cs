using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyTurnState : StateList
{
    public override void EnterState(CombatStateManager currentTurn)
    {
        currentTurn.currentTime = 0f;
        Debug.Log("Enemy turn begun");
    }

    public override void UpdateState(CombatStateManager currentTurn)
    {
        if (currentTurn.currentTime < currentTurn.enemyTurnTime)
        {
            // add a visual timer indicator
            currentTurn.currentTime += Time.deltaTime;
        }
        else
        {
            currentTurn.EndTurn(currentTurn.PlayerTurn);
        }
    }

    public override void ExitState(CombatStateManager currentTurn)
    {
 
    }


}
