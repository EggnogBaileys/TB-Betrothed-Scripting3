using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TransitionTurnState : StateList
{
    public override void EnterState(CombatStateManager currentTurn)
    {

    }

    public override void UpdateState(CombatStateManager currentTurn)
    {

    }

    public override void ExitState(CombatStateManager currentTurn)
    {

    }
}
