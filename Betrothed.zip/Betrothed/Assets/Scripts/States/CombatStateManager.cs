using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class CombatStateManager : MonoBehaviour
{
    StateList currentTurn;

    // Both main states of combat - either the enemy turn, or the player turn.
    public EnemyTurnState EnemyTurn = new EnemyTurnState();
    public PlayerTurnState PlayerTurn = new PlayerTurnState();
    public TransitionTurnState TransitionTurn = new TransitionTurnState();

    public float currentTime;

    // Timers to signify how long a player or enemy's turn will last before switching.
    public float playerTurnTime;
    public float enemyTurnTime;
    public float transitionTurnTime;

    public TMP_Text turnLabel;

    // This public variable is for other scripts to reference, so they can behave according to their turn.
    public StateList turnReference;

    public AudioSource audioSource;


    void Start()
    {
        EndTurn(PlayerTurn);

        currentTurn.EnterState(this);

    }

    void Update()
    {
        currentTurn.UpdateState(this);
    }



    public void EndTurn(StateList turn)
    {

        currentTurn = TransitionTurn;
        currentTurn.EnterState(this);

        Time.timeScale = 1;

        turnReference = currentTurn;

        StartCoroutine(ChangeTurns(turn));
    }


    public IEnumerator ChangeTurns(StateList turn)
    {
        if (turn == EnemyTurn) turnLabel.text = "DEFEND";
        else turnLabel.text = "ATTACK";

        audioSource.Play(0);

        yield return new WaitForSeconds(transitionTurnTime);

        turnLabel.text = string.Empty;

        currentTurn = turn;
        turnReference = currentTurn;

        turn.EnterState(this);
    }




}
