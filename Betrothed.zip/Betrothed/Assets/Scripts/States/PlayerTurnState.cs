using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerTurnState : StateList
{
    public override void EnterState(CombatStateManager currentTurn)
    {
        Debug.Log("Player turn begun");
        currentTurn.currentTime = 0f;
    }

    public override void UpdateState(CombatStateManager currentTurn)
    {
        if (currentTurn.currentTime < currentTurn.playerTurnTime)
        {
            // add a visual timer indicator
            currentTurn.currentTime += Time.deltaTime;
        }
        else
        {
            currentTurn.EndTurn(currentTurn.EnemyTurn);
        }

    }

    public override void ExitState(CombatStateManager currentTurn)
    {

    }
}
