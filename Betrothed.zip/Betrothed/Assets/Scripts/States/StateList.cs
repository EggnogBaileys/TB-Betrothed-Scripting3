
using UnityEngine;

public abstract class StateList
{
    public abstract void EnterState(CombatStateManager currentTurn);

    public abstract void UpdateState(CombatStateManager currentTurn);

    public abstract void ExitState(CombatStateManager currentTurn);
}
