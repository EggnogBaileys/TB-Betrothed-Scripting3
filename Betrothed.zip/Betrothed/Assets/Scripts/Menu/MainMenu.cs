using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public string nextScene;
    public void Begin()
    {
        SceneManager.LoadScene(nextScene);
    }

    public void Rest()
    {
        Application.Quit();
    }

}
