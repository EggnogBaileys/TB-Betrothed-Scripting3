using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Player : MonoBehaviour
{
    public CombatStateManager combatStateManager;

    public GameObject spear;
    public GameObject shield;
    //TextMeshPro shieldPercent;
    public int shieldPercentValue = 100;

    GameObject newSpear;
    GameObject newShield;

    StateList currentTurn;

    void Start()
    {
        currentTurn = combatStateManager.turnReference;
    }

    void Update()
    {
        if (currentTurn != combatStateManager.turnReference) ChangeTurn();

        if (combatStateManager.turnReference == combatStateManager.EnemyTurn && shieldPercentValue < 1)
        {
            if (newShield != null) Destroy(newShield);
        }
    }

    public void UpdateShieldPercent()
    {
        
        shieldPercentValue -= Manager.instance.ShieldDamage;
        GameObject.Find("ShieldPercent").GetComponent<TextMeshPro>().text = shieldPercentValue.ToString() + "%";
    }

    void ChangeTurn()
    {
        if (combatStateManager.turnReference == combatStateManager.PlayerTurn)
        {
            
            currentTurn = combatStateManager.turnReference;
            newSpear = Instantiate(spear, new Vector3(0, -1.74f, 0), Quaternion.identity);

        }
        else if (combatStateManager.turnReference == combatStateManager.EnemyTurn)
        {
            
            currentTurn = combatStateManager.turnReference;
            newShield = Instantiate(shield, new Vector3(0, -1.74f, 0), Quaternion.identity);

            GameObject.Find("ShieldPercent").GetComponent<TextMeshPro>().text = shieldPercentValue.ToString() + "%";

        }
        else if (combatStateManager.turnReference == combatStateManager.TransitionTurn)
        {

            Destroy(newSpear);
            Destroy(newShield);

            currentTurn = combatStateManager.turnReference;

        }
    }

}
