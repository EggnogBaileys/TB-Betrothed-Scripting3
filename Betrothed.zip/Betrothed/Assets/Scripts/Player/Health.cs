using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Health : MonoBehaviour
{
    public int health = 10;
    public HealthBar healthbar;

    private void Start()
    {
        health = Manager.instance.PlayerHealth;
        healthbar.SetMaxHealth(health);
        
        healthbar.SetHealth(health);
        health = Manager.instance.PlayerHealth;
    }

}
