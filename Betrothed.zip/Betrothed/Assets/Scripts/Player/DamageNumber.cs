using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class DamageNumber : MonoBehaviour
{
    public TMP_Text damageText;

    private void Start()
    {
        this.gameObject.transform.position += new Vector3(0, 0.7f, 0);
    }

    private void Update()
    {
        this.gameObject.transform.position += new Vector3(0, Time.deltaTime * 1.25f, 0);    
    }

    public void ShowDamage(int damage)
    {
        damageText.text = damage.ToString();
        Destroy(this.gameObject, 0.75f);
    }
}
