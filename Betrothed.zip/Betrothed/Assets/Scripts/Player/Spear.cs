using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spear : MonoBehaviour
{
    public GameObject spear;

    public float defaultSpearSpeed = 140f;
    public float spearSpeed = 140f;

    public bool canMoveSpear = true;
    public bool canSwingSpear = true;
    public bool charging = false;

    float chargeTime = 1.0f;
    float currentTime = 0f;
    public bool fullyCharged = false;

    public Sprite chargedSpear;
    public Sprite defaultSpear;

    public SpriteRenderer currentTool;


    public Animator animator;
    Rigidbody rb;

    AudioSource audioPlayer;

    public AudioClip swing;
    public AudioClip charge;



    void Start()
    {
        audioPlayer = this.gameObject.GetComponent<AudioSource>();

        currentTool.sprite = defaultSpear;
        rb = this.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        SpearMove();
        CheckForSwing();

    }

    public void SpearMove()
    {
        // Regular movement.
        if (this.gameObject.transform.position.x > -8 && Input.GetKey(KeyCode.A))
        {
            rb.AddForce(-spearSpeed * Time.deltaTime * 20f, 0, 0);
        }
        else if (this.gameObject.transform.position.x < 8 && Input.GetKey(KeyCode.D))
        {
            rb.AddForce(spearSpeed * Time.deltaTime * 20f, 0, 0);
        }

        // If the spear goes over the boundaries (for some reason, collider walls weren't working)
        else if (this.gameObject.transform.position.x <= -8)
        {
            rb.AddForce((spearSpeed / 1.25f) * Time.deltaTime * 20f, 0, 0);
        }
        else if (this.gameObject.transform.position.x >= 8)
        {
            rb.AddForce((-spearSpeed / 1.25f) * Time.deltaTime * 20f, 0, 0);
        }

    }


    public void CheckForSwing()
    {

        if (canSwingSpear && Input.GetMouseButton(0) && !charging)
        {
            ChargeSpear();
        }

        else if (canSwingSpear && charging && Input.GetMouseButton(0))
        {
            currentTime = currentTime += Time.deltaTime;

            if (currentTime > chargeTime / 2 && audioPlayer.clip != charge)
            {
                audioPlayer.clip = charge;
                audioPlayer.Play(0);
            }

            if (currentTime > chargeTime && !fullyCharged)
            {
                currentTool.sprite = chargedSpear;
                fullyCharged = true;
                spearSpeed = spearSpeed / 2.5f;
            }
        }

        if (Input.GetMouseButtonUp(0) && canSwingSpear)
        {
            audioPlayer.clip = swing;
            audioPlayer.Play(0);
            spearSpeed = defaultSpearSpeed;
            SwingSpear();
        }

    }

    private void ChargeSpear()
    {
        animator.SetTrigger("OnCharge");
        charging = true;
    }

    private void SwingSpear()
    {
        animator.SetTrigger("OnSwing");
        canSwingSpear = false;
        charging = false;
    }

    private void StopSwingingSpear()
    {
        currentTime = 0;
        fullyCharged = false;
        currentTool.sprite = defaultSpear;
        canSwingSpear = true;
        animator.SetTrigger("StopSwinging");
    }
    




    void SyncAnimator()
    {
        
    }



}
