using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shield : MonoBehaviour
{
    public GameObject shield;

    public float defaultShieldSpeed = 140f;
    public float shieldSpeed = 140f;

    public bool canMoveShield = true;

    AudioSource audioPlayer;

    Rigidbody rb;

    void Start()
    {
        audioPlayer = this.gameObject.GetComponent<AudioSource>();
        rb = this.GetComponent<Rigidbody>();
    }


    void Update()
    {
        ShieldMove();
    }

    public void ShieldMove()
    {
        // Regular movement.
        if (this.gameObject.transform.position.x > -8 && Input.GetKey(KeyCode.A))
        {
            rb.AddForce(-shieldSpeed * Time.deltaTime * 20f, 0, 0);
        }
        else if (this.gameObject.transform.position.x < 8 && Input.GetKey(KeyCode.D))
        {
            rb.AddForce(shieldSpeed * Time.deltaTime * 20f, 0, 0);
        }

        // If the shield goes over the boundaries (for some reason, collider walls weren't working)
        else if (this.gameObject.transform.position.x <= -8)
        {
            rb.AddForce((shieldSpeed / 1.25f) * Time.deltaTime * 20f, 0, 0);
        }
        else if (this.gameObject.transform.position.x >= 8)
        {
            rb.AddForce((-shieldSpeed / 1.25f) * Time.deltaTime * 20f, 0, 0);
        }
    }
}
