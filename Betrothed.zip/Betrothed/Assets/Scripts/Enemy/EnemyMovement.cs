using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{

    public bool isSpidehr;
    bool needsToClimb = true;

    // Enemy's Movement Speed

    public float defaultSpeed = 8f;
    public float speed = 8f;

    // Keep these static.
    private float zOrder = 0f;
    private float yOrder = 0f;

    float[] xPos;


    Vector3 nextMovement;

    public bool moving;
    public bool canMove = true;

    // Does not need to be manually set. Will be automatically chosen by the enemy.
    public int movementChoice = 0;

    // Start is called before the first frame update
    void Start()
    {
        // Possible movements locations that it can choose to slide to randomly.
        xPos = new float[5];

        xPos[0] = 0f;
        xPos[1] = -3.5f;
        xPos[2] = 3.5f;
        xPos[3] = -5f;
        xPos[4] = 6f;

        // Sets the spawnpoint of the enemy to this Vector3.
        nextMovement = new Vector3(xPos[0], yOrder, zOrder);
        transform.position = nextMovement;

    }

    // Update is called once per frame
    void Update()
    {

        if (isSpidehr) SpidehrMovement();

        if (!moving && canMove)
        {
            movementChoice = ChooseNextMovement(movementChoice);
            canMove = false;
            moving = true;
        }

        if (moving)
        {
            Move();
        }
    }

    int ChooseNextMovement(int previousChoice)
    {
        // A looping if-check to make sure that the new choice isn't the same as the previous one.
        int choice = previousChoice;
        while (previousChoice == choice)
        {
            choice = Random.Range(0, 4);
        }

        return choice;
    }



    void Move()
    {
        if (transform.position.x < xPos[movementChoice] && transform.position.x != xPos[movementChoice])
        {
            transform.position += new Vector3(speed * Time.deltaTime, 0, 0);
            if (transform.position.x >= xPos[movementChoice])
            {
                moving = false;
                canMove = true;
            }
        }
        else if (transform.position.x > xPos[movementChoice] && transform.position.x != xPos[movementChoice])
        {
            transform.position += new Vector3(-speed * Time.deltaTime, 0, 0);
            if (transform.position.x <= xPos[movementChoice])
            {
                moving = false;
                canMove = true;
            }
        }
    }

    void SpidehrMovement()
    {
        if (transform.position.y <= 3.5f && needsToClimb)
        {
            transform.position += new Vector3(0, speed / 2 * Time.deltaTime, 0);
            if (transform.position.y >= 3.5f) needsToClimb = false;
        }
        else if (transform.position.y >= -0.25f && !needsToClimb)
        {
            transform.position -= new Vector3(0, speed / 2 * Time.deltaTime, 0);
            if (transform.position.y <= -0.25f) needsToClimb = true;
        }
    }

}
