using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hazard : MonoBehaviour
{
    public GameObject sprite;
    float flickerSpeed = 0.22f;

    public GameObject collision;

    EnemyStates enemyStates;
  


    void Start()
    {
        enemyStates = FindObjectOfType<EnemyStates>();
        StartCoroutine(Flickering());
    }

    private void Update()
    {
        if (enemyStates == null) Destroy(this.gameObject);
        else if (!enemyStates.GetComponent<EnemyAttack>().attackTurn) Destroy(this.gameObject);
    }


    public void CanAttack(bool attackTurn)
    {
        if (!attackTurn)
        {
            Destroy(this.gameObject);
        }
    }


    // Enemy Attack script would refer to this when spawning a new hazard, and would pass in the attackDelay value.
    public void PreppingAttack(float attackDelay)
    {
        StartCoroutine(PreppingAttackTimer(attackDelay));
    }

    IEnumerator PreppingAttackTimer(float attackDelay)
    {
        yield return new WaitForSeconds(attackDelay);

        GameObject hitboxSpawn = Instantiate(collision, this.transform.position, Quaternion.identity);


        Destroy(this.gameObject);
    }






    public IEnumerator Flickering()
    {
        while (this.gameObject.activeSelf)
        {
            sprite.SetActive(true);
            yield return new WaitForSeconds(flickerSpeed);
            sprite.SetActive(false);
            yield return new WaitForSeconds(flickerSpeed);
        }
    }
}
