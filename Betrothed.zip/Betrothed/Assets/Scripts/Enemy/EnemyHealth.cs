using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class EnemyHealth : MonoBehaviour
{
    public int health = 10;
    int maxHealth;

    public GameObject damageNumber;

    public Sprite defaultEnemy;
    public Sprite hitEnemy;

    public SpriteRenderer sprite;

    Spear spearScript;

    AudioSource audioPlayer;

    public AudioClip stab;
    public AudioClip bigstab;

    public TextMeshPro healthLabel;

    NumberOfEnemies numberOfEnemies;

    void Start()
    {
        numberOfEnemies = FindObjectOfType<NumberOfEnemies>();

        maxHealth = health;
        healthLabel.text = health.ToString() + "/" + maxHealth.ToString();
        audioPlayer = this.gameObject.GetComponent<AudioSource>();
    }

    void UpdateHealthLabel()
    {
        if (health > -1) healthLabel.text = health.ToString() + "/" + maxHealth.ToString();
        else healthLabel.text = "0/" + maxHealth.ToString();
    }    
    


    private void OnTriggerEnter(Collider collision)
    {
        if (collision.CompareTag("spear"))
        {

            if (this.gameObject.GetComponent<EnemyAttack>().enemyType == EnemyAttack.EnemyType.Shield)
            {
                Destroy(GameObject.Find("Spear(Clone)"));
            }

            spearScript = collision.gameObject.GetComponentInParent<Spear>();
            if (spearScript.fullyCharged)
            {
                audioPlayer.clip = bigstab;
                audioPlayer.Play(0);

                GameObject damageNum = Instantiate(damageNumber, this.transform.position, Quaternion.identity);
                damageNum.GetComponent<DamageNumber>().ShowDamage(Manager.instance.ChargeDamage);


                health -= Manager.instance.ChargeDamage;
            }
            else
            {
                audioPlayer.clip = stab;
                audioPlayer.Play(0);

                GameObject damageNum = Instantiate(damageNumber, this.transform.position, Quaternion.identity);
                damageNum.GetComponent<DamageNumber>().ShowDamage(1);

                health -= 1;
            }
            StartCoroutine(HitEnemy());
        }
    }

    IEnumerator HitEnemy()
    {
        UpdateHealthLabel();

        sprite.sprite = hitEnemy;
        if (spearScript.fullyCharged)
        {
            Time.timeScale = 0.1f;
            yield return new WaitForSeconds(.075f);
            Time.timeScale = 1;
        }
        else yield return new WaitForSeconds(.25f);
        sprite.sprite = defaultEnemy;

        if (health < 1)
        {
            numberOfEnemies.enemyNum -= 1;

            if (numberOfEnemies.enemyNum < 1)
            {
                GameObject.Find("Combat State Manager").GetComponent<EndBattle>().EndCombat("Victory");
                Destroy(GameObject.Find("Spear(Clone)"));
            }

            Destroy(this.gameObject);
        }
    }
}
