using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hitbox : MonoBehaviour
{
    bool blocked;
    bool checkLateUpdate;

    EnemyAttack enemyAttack;
    Health playerHealth;

    Player playerScript;

    void Start()
    {
        playerScript = FindObjectOfType<Player>();

        enemyAttack = FindObjectOfType<EnemyAttack>();
        playerHealth = FindObjectOfType<Health>();

        StartCoroutine(CheckLate());
    }

    private void LateUpdate()
    {
        if (!blocked && checkLateUpdate)
        {
            checkLateUpdate = false;
            print("hit player");

            enemyAttack.audioPlayer.clip = enemyAttack.stab;
            enemyAttack.audioPlayer.Play(0);

            playerHealth.health -= 1;
            playerHealth.healthbar.SetHealth(playerHealth.health);

            if (playerHealth.health < 1)
            {
                GameObject.Find("Combat State Manager").GetComponent<EndBattle>().EndCombat("Loss");

                Destroy(playerHealth.gameObject);
                Destroy(GameObject.Find("Shield(Clone)"));
                Destroy(FindObjectOfType<EnemyAttack>().gameObject);
            }

            Destroy(this.gameObject, 0.01f);
        }
    }

    IEnumerator CheckLate()
    {
        yield return new WaitForSeconds(0.05f);
        checkLateUpdate = true;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!blocked)
        {
            Collider[] hitColliders = Physics.OverlapBox(GetComponent<Collider>().bounds.center, new Vector3(GetComponent<Collider>().bounds.size.x / 2, GetComponent<Collider>().bounds.size.y / 2, GetComponent<Collider>().bounds.size.z / 2), Quaternion.identity);
            foreach (Collider i in hitColliders)
            {
                if (i.gameObject.CompareTag("shield"))
                {
                    blocked = true;
                    print("Blocked");
                    enemyAttack.audioPlayer.clip = enemyAttack.block;
                    enemyAttack.audioPlayer.Play(0);

                    playerScript.UpdateShieldPercent();

                    Destroy(this.gameObject, 0.02f);
                }
            }
        }
    }
}
