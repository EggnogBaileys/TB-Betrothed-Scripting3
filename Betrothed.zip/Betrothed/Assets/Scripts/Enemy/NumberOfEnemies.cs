using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NumberOfEnemies : MonoBehaviour
{
    public int enemyNum;
}
