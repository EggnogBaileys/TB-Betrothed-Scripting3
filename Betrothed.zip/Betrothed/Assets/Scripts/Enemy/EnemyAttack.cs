using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAttack : MonoBehaviour
{
    // Note to self: This script needs to be a separate entity of the enemy that is activated and deactivated.
    // Maybe, even instantiated, with the enum being the only element necessary for clarification.

    public bool attackTurn;
    public bool attacking;
    bool attackDone;

    public GameObject hazard;

    public enum EnemyType
    {
        Ratto,
        Skellington,
        Spidehr,
        Grongus,
        Shield,
        Ratto2
    }

    public EnemyType enemyType;

    // Values determining specific attacks

    float attackDelay;
    float attackPatternDelay;

    bool easyAttacks;
    bool mediumAttacks;
    bool hardAttacks;
    //bool chaoticAttacks;

    // Between 1 to 10, chance that a harder attack type will be used.
    int harderAttackRarity;
    int attackChoice;

    bool shieldActive; 

    public AudioSource audioPlayer;

    public AudioClip stab;
    public AudioClip block;

    public GameObject grongShield;

    void Start()
    {
        switch (enemyType)
        {
            case EnemyType.Ratto:

                easyAttacks = true;
                mediumAttacks = true;
                harderAttackRarity = 7;
                attackDelay = 1.06f;
                attackPatternDelay = 0.75f;

                break;

            case EnemyType.Skellington:

                mediumAttacks = true;
                hardAttacks = true;
                harderAttackRarity = 8;
                attackDelay = 0.88f;
                attackPatternDelay = 0.85f;

                break;

            case EnemyType.Spidehr:

                mediumAttacks = true;
                hardAttacks = true;
                harderAttackRarity = 5;
                attackDelay = 0.79f;
                attackPatternDelay = 0.75f;

                break;

            case EnemyType.Grongus:

                hardAttacks = true;
                //chaoticAttacks = true;
                harderAttackRarity = 6;
                attackDelay = 0.76f;
                attackPatternDelay = 0.25f;

                break;

            case EnemyType.Shield:

                break;

            case EnemyType.Ratto2:

                easyAttacks = true;
                mediumAttacks = true;
                harderAttackRarity = 7;
                attackDelay = 1.06f;
                attackPatternDelay = 1.0f;

                break;
        }
    }


    void Update()
    {
        if (enemyType == EnemyType.Grongus && this.gameObject.GetComponent<EnemyHealth>().health < 31 && !shieldActive)
        {
            shieldActive = true;
            grongShield.SetActive(true);
        }

        if (enemyType == EnemyType.Grongus && this.gameObject.GetComponent<EnemyHealth>().health < 16 && this.gameObject.GetComponent<EnemyMovement>().isSpidehr != true)
        {
            this.gameObject.GetComponent<EnemyMovement>().isSpidehr = true;
        }

        if (!attacking && attackTurn && enemyType != EnemyType.Shield)
        {
            attacking = true;
            attackChoice = Random.Range(1, 10);

            ChooseAttackDifficulty(attackChoice);
        }
        if (attackDone && enemyType != EnemyType.Shield)
        {
            attackDone = false;
            StartCoroutine(NextAttackDelay());
        }
    }

    IEnumerator NextAttackDelay()
    {
        yield return new WaitForSeconds(attackPatternDelay);
        attacking = false;
    }

    // If-Checks to determine the difficulty of the attack chosen.
    void ChooseAttackDifficulty(int attackChoice)
    {
        if (attackChoice < harderAttackRarity)
        {
            if (easyAttacks) EasyAttack();
            else if (mediumAttacks) MediumAttack();
            else if (hardAttacks) HardAttack();
        }

        else if (attackChoice >= harderAttackRarity)
        {
            if (easyAttacks) MediumAttack();
            else if (mediumAttacks) HardAttack();
            else if (hardAttacks) ChaoticAttack();
        }
    }

    void EasyAttack()
    {
        attackChoice = Random.Range(1, 9);

        if (attackChoice < 4) StartCoroutine(EasyAttack1());
        else if (attackChoice > 3 && attackChoice < 7) StartCoroutine(EasyAttack2());
        else if (attackChoice > 6) StartCoroutine(EasyAttack3());

    }

    void MediumAttack()
    {
        attackChoice = Random.Range(1, 10);
        if (attackChoice < 3) StartCoroutine(MediumAttack1());
        else if (attackChoice > 2 && attackChoice < 5) StartCoroutine(MediumAttack2());
        else if (attackChoice > 4 && attackChoice < 7) StartCoroutine(MediumAttack3());
        else if (attackChoice > 6 && attackChoice < 9) StartCoroutine(MediumAttack4());
        else if (attackChoice > 8) StartCoroutine(MediumAttack5());

    }

    void HardAttack()
    {
        attackChoice = Random.Range(1, 10);

        if (attackChoice < 3) StartCoroutine(HardAttack1());
        else if (attackChoice > 2 && attackChoice < 5) StartCoroutine(HardAttack2());
        else if (attackChoice > 4 && attackChoice < 8) StartCoroutine(HardAttack3());
        else if (attackChoice > 7) StartCoroutine(HardAttack4());

    }

    void ChaoticAttack()
    {
        EasyAttack();
        EasyAttack();
    }


    // specific attacks

    IEnumerator EasyAttack1()
    {
        SpawnAttack(0);

        yield return new WaitForSeconds(attackDelay);

        attackDone = true;
    }

    IEnumerator EasyAttack2()
    {
        SpawnAttack(-3);

        yield return new WaitForSeconds(attackDelay);

        attackDone = true;
    }

    IEnumerator EasyAttack3()
    {
        SpawnAttack(3);

        yield return new WaitForSeconds(attackDelay);

        attackDone = true;
    }


    IEnumerator MediumAttack1()
    {
        SpawnAttack(0f);
        yield return new WaitForSeconds(attackDelay);
        SpawnAttack(-5f);
        yield return new WaitForSeconds(attackDelay);
        SpawnAttack(3f);
        yield return new WaitForSeconds(attackDelay);

        attackDone = true;
    }
    IEnumerator MediumAttack2()
    {
        SpawnAttack(-4f);
        yield return new WaitForSeconds(attackDelay);
        SpawnAttack(0f);
        yield return new WaitForSeconds(attackDelay);
        SpawnAttack(3f);
        yield return new WaitForSeconds(attackDelay);

        attackDone = true;
    }

    IEnumerator MediumAttack3()
    {
        SpawnAttack(4f);
        yield return new WaitForSeconds(attackDelay);
        SpawnAttack(-4f);
        yield return new WaitForSeconds(attackDelay);
        SpawnAttack(3f);
        yield return new WaitForSeconds(attackDelay);

        attackDone = true;
    }

    IEnumerator MediumAttack4()
    {
        SpawnAttack(0f);
        yield return new WaitForSeconds(attackDelay);
        SpawnAttack(4f);
        yield return new WaitForSeconds(attackDelay);
        SpawnAttack(-3f);
        yield return new WaitForSeconds(attackDelay);

        attackDone = true;
    }

    IEnumerator MediumAttack5()
    {
        SpawnAttack(-4f);
        yield return new WaitForSeconds(attackDelay);
        SpawnAttack(4f);
        yield return new WaitForSeconds(attackDelay);
        SpawnAttack(-3f);
        yield return new WaitForSeconds(attackDelay);

        attackDone = true;
    }



    IEnumerator HardAttack1()
    {
        SpawnAttack(-4);
        SpawnAttack(-2);
        yield return new WaitForSeconds(attackDelay);

        SpawnAttack(4);
        SpawnAttack(2);
        yield return new WaitForSeconds(attackDelay);

        attackDone = true;
    }

    IEnumerator HardAttack2()
    {
        SpawnAttack(4);
        SpawnAttack(2);
        yield return new WaitForSeconds(attackDelay);

        SpawnAttack(-2);
        SpawnAttack(-4);
        yield return new WaitForSeconds(attackDelay);

        attackDone = true;
    }

    IEnumerator HardAttack3()
    {
        SpawnAttack(-5);

        yield return new WaitForSeconds(attackDelay);

        SpawnAttack(-2);
        yield return new WaitForSeconds(attackDelay/1.5f);
        SpawnAttack(0);
        yield return new WaitForSeconds(attackDelay/1.5f);
        SpawnAttack(2);
        yield return new WaitForSeconds(attackDelay/1.5f);
        SpawnAttack(4);
        yield return new WaitForSeconds(attackDelay/1.5f);
        SpawnAttack(6);
        yield return new WaitForSeconds(attackDelay);

        attackDone = true;
    }

    IEnumerator HardAttack4()
    {
        SpawnAttack(5);

        yield return new WaitForSeconds(attackDelay);

        SpawnAttack(2);
        yield return new WaitForSeconds(attackDelay / 1.5f);
        SpawnAttack(0);
        yield return new WaitForSeconds(attackDelay / 1.5f);
        SpawnAttack(-2);
        yield return new WaitForSeconds(attackDelay / 1.5f);
        SpawnAttack(-4);
        yield return new WaitForSeconds(attackDelay / 1.5f);
        SpawnAttack(-6);
        yield return new WaitForSeconds(attackDelay);

        attackDone = true;
    }


    void SpawnAttack(float xPos)
    {
        GameObject attack = Instantiate(hazard, new Vector3(xPos, 0, 0), Quaternion.identity);
        attack.GetComponent<Hazard>().PreppingAttack(attackDelay);
        attack.GetComponent<Hazard>().CanAttack(attackTurn);
    }

}
