using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyStates : MonoBehaviour
{
    public CombatStateManager combatStateManager;

    StateList currentTurn;

    EnemyAttack enemyAttack;
    EnemyMovement enemyMovement;
    EnemyHealth enemyHealth;

    public GameObject healthLabelObject;

    void Start()
    {
        healthLabelObject.SetActive(false);

        currentTurn = combatStateManager.turnReference;

        enemyAttack = this.gameObject.GetComponent<EnemyAttack>();
        enemyMovement = this.gameObject.GetComponent<EnemyMovement>();
        enemyHealth = this.gameObject.GetComponent<EnemyHealth>();

        enemyMovement.speed = 0;
    }

    void Update()
    {

        // Activate enemy dodging
        if (combatStateManager.turnReference == combatStateManager.PlayerTurn)
        {
            healthLabelObject.SetActive(true);
            if (enemyMovement.speed != enemyMovement.defaultSpeed) enemyMovement.speed = enemyMovement.defaultSpeed;
            currentTurn = combatStateManager.turnReference;
        }

        // Activate enemy attacks
        else if (combatStateManager.turnReference == combatStateManager.EnemyTurn)
        {
            if (enemyMovement.speed == 0) enemyMovement.speed = enemyMovement.defaultSpeed / 2;

            currentTurn = combatStateManager.turnReference;
            this.gameObject.GetComponent<EnemyAttack>().attackTurn = true;
        }

        // Deactivate enemy attacks and dodging
        else if (combatStateManager.turnReference == combatStateManager.TransitionTurn)
        {
            healthLabelObject.SetActive(false);
            if (enemyMovement.speed != 0) enemyMovement.speed = 0;
            currentTurn = combatStateManager.turnReference;
            this.gameObject.GetComponent<EnemyAttack>().attackTurn = false;
        }
    }
}
