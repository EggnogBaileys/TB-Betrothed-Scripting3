using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class EndStats : MonoBehaviour
{

    public TextMeshProUGUI upgrade1;
    public TextMeshProUGUI upgrade2;
    public TextMeshProUGUI upgrade3;
    public TextMeshProUGUI totalDeaths;

    void Start()
    {
        upgrade1.text = "Health Upgrades: " + Manager.instance.healthUpgrades.ToString();
        upgrade2.text = "Charge Atk Upgrades: " + Manager.instance.damageUpgrades.ToString();
        upgrade3.text = "Defensive Upgrades: " + Manager.instance.defenseUpgrades.ToString();

        totalDeaths.text = "Total Deaths: " + Manager.instance.totalDeaths.ToString();
    }


}
