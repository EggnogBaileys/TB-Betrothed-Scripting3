using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Manager : MonoBehaviour
{
    public static Manager instance;

    public int PlayerHealth;
    
    public int ShieldDamage;
    
    public int ChargeDamage;

    public int healthUpgrades = 0;
    public int damageUpgrades = 0;
    public int defenseUpgrades = 0;
    public int totalDeaths = 0;

    void Awake()
    {
        if (instance != null && instance != this) Destroy(this);
        else instance = this;

        DontDestroyOnLoad(this.gameObject);    
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
