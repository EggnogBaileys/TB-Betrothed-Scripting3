using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Reset : MonoBehaviour
{

    private void Start()
    {
        Manager.instance.ChargeDamage = 3;
        Manager.instance.PlayerHealth = 6;
        Manager.instance.ShieldDamage = 5;
        Manager.instance.totalDeaths = 0;
        Manager.instance.damageUpgrades = 0;
        Manager.instance.healthUpgrades = 0;
        Manager.instance.damageUpgrades = 0;
    }
}
