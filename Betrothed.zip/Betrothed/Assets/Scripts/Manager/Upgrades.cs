using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Upgrades : MonoBehaviour
{
    public string nextScene;

    public enum Upgrade1
    {
        chargeDamage,
        shieldSpeed,
        playerHealth
    }

    public Upgrade1 upgrade1;

    public enum Upgrade2
    {
        chargeDamage,
        shieldSpeed,
        playerHealth
    }

    public Upgrade2 upgrade2;



    public void Upgrade1Chosen()
    {
        switch (upgrade1)
        {
            case Upgrade1.chargeDamage:

                Manager.instance.ChargeDamage += 1;
                Manager.instance.damageUpgrades += 1;

                break;

            case Upgrade1.playerHealth:

                Manager.instance.PlayerHealth += 6;
                Manager.instance.healthUpgrades += 1;

                break;

            case Upgrade1.shieldSpeed:
                
                Manager.instance.ShieldDamage -= 2;
                Manager.instance.defenseUpgrades += 1;

                break;
        }
        SceneManager.LoadScene(nextScene);
    }

    public void Upgrade2Chosen()
    {
        switch (upgrade2)
        {
            case Upgrade2.chargeDamage:

                Manager.instance.ChargeDamage += 1;
                Manager.instance.damageUpgrades += 1;

                break;

            case Upgrade2.playerHealth:

                Manager.instance.PlayerHealth += 6;
                Manager.instance.healthUpgrades += 1;

                break;

            case Upgrade2.shieldSpeed:

                Manager.instance.ShieldDamage -= 2;
                Manager.instance.defenseUpgrades += 1;

                break;
        }
        NextScene();
    }


    public void NextScene()
    {
        SceneManager.LoadScene(nextScene);
    }

    public void NewGamePlus()
    {
        SceneManager.LoadScene("Tutorial");
    }

    public void MainMenuBack()
    {
        SceneManager.LoadScene("TitlePage");
    }

}
